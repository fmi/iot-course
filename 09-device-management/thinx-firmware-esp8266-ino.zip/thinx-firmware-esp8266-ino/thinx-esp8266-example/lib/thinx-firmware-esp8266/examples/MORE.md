# More examples

[Quadruple Humidity Monitor for MQTT/InfluxDB/Grafana](https://github.com/suculent/thinx-example-flowers)
