const char *apikey = "71679ca646c63d234e957e37e4f4069bf4eed14afca4569a0c74abf503076732";
const char *owner_id = "cedc16bb6bb06daaa3ff6d30666d91aacd6e3efbf9abbc151b4dcade59af7c12";
const char *ssid = "THiNX-IoT+";
const char *pass = "<enter-your-ssid-password>";
